# onePageChords
One Page Chords helps you create a single, printable page of chords and lyrics

This is kind of a placeholder.  The code was on my website from several years ago, and is frankly kind of trash.  But it works!  And since I let my domain expire I wanted a place to run this project.  Converted to do client side PDF generation.  May eventually come in and refactor it all.  For now, just did bare minimum to make it work.
